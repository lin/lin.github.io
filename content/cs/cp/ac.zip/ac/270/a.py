a, b = map(int, input().split())

print(a|b)