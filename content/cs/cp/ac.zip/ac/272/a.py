n = int(input())

print(sum(map(int, input().split())))