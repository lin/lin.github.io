n, k, d = tuple(map(int, input().split()))

nums = list(map(int, input().split()))

