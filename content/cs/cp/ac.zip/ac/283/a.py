a,b=tuple(map(int, input().split()))
print(a**b)