a, b = tuple(map(int, input().split()))
print("Yes" if b//2 == a else "No")