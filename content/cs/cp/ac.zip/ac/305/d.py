from sys import stdin
input = stdin.readline

from math import *
from collections import defaultdict, Counter, deque

n, k = map(int, input().split())
A = list(map(int, input().split()))
n = int(input())
s = input().strip()