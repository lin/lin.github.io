from sys import stdin
input = stdin.readline

from math import *

ii = lambda: int(input())
li = lambda: list(map(int, input().split()))
ti = lambda: map(int, input().split())
si = lambda: input().strip()

n = ii()

s = si()
nums = li()